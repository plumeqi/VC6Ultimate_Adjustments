// RC.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#include <windows.h>

typedef int (__stdcall * RCFuncPtr)(int a1, int a2, char *Str);
typedef BOOL (__stdcall *HandlerPtr)(DWORD dwCtrlType);
typedef int (__stdcall *RCPtr)(int a1, int a2, RCFuncPtr pFunc, int a3, int argc, char* argv[]);

int __stdcall sub_10010F0(int a1, int a2, char *Str)
{
  char *v3; // esi
  int v4; // edi
  char *v5; // eax
  char v6; // dl
  char *v7; // ecx
  char *v8; // edi
  int v9; // edx
  char v10; // al
  const char *v11; // eax
  char *v12; // ecx

  v3 = Str;
  v4 = strlen(Str);
  v5 = strchr(Str, 37);
  if ( v4 >= 2 )
  {
    if ( (v6 = Str[v4 - 1], v7 = &Str[v4], v6 == 10) && *(v7 - 2) == 13 || v6 == 13 && *(v7 - 2) == 10 )
      *(v7 - 2) = 0;
  }
  if ( *Str )
  {
    if ( v5 )
    {
      v8 = Str;
      v9 = 0;
      v10 = *Str;
      do
      {
        if ( v10 == 37 )
          ++v9;
        v10 = *++v8;
      }
      while ( v10 );
      v11 = (const char *)malloc(strlen(Str) + 1 + v9);
      if ( v11 )
      {
        v12 = (char *)v11;
        while ( *v3 )
        {
          if ( *v3 == 37 )
            *v12++ = 37;
          *v12++ = *v3++;
        }
        *v12 = 0;
        printf(v11);
        goto LABEL_23;
      }
      while ( strchr(Str, 37) )
        *strchr(Str, 37) = 32;
    }
    printf(Str);
  }
LABEL_23:
  printf("\n");
  return 0;
}

int main(int argc, char* argv[])
{
  int iExitCode = 0;
  HMODULE hDll = NULL;
	HandlerPtr HandlerFunc = NULL;
	RCPtr RCFunc = NULL;

  hDll = LoadLibrary("RCDLL.dll");
	if( hDll == NULL )
	{
      MessageBox(NULL,"Can not load dll: RCDLL.dll.", "Error",MB_OK);
			goto EXIT;
	}

	HandlerFunc = (HandlerPtr)GetProcAddress(hDll,"Handler");
  if(HandlerFunc == NULL )
	{
		MessageBox(NULL,"Can not find function: Handler.", "Error",MB_OK);
		goto EXIT;
	}

  RCFunc = (RCPtr)GetProcAddress(hDll,"RC");
  if(RCFunc == NULL )
	{
		MessageBox(NULL,"Can not find function: RC.", "Error",MB_OK);
		goto EXIT;
	}

  SetConsoleCtrlHandler(HandlerFunc,TRUE);
  iExitCode = RCFunc(0,0,sub_10010F0,0,argc,argv);
  SetConsoleCtrlHandler(HandlerFunc,FALSE);
EXIT:
  if( hDll != NULL )
	{
		FreeLibrary(hDll);
		hDll = NULL;
	}

	return iExitCode;
}
