#ifndef __EXPORT_H__
#define __EXPORT_H__

#ifdef __cplusplus
extern "C" {
#endif

int ExportFunc01(int a);
int ExportFunc02(int a, int b);

#ifdef __cplusplus
}
#endif

#endif
