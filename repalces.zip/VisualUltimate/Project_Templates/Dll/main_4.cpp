#include <windows.h>
#include "export.h"

//---------------------------------------------------------------------------------------
BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, void* lpReserved)
{
  switch (ul_reason_for_call)
  {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
      break;
  }
  return TRUE;
}
//---------------------------------------------------------------------------------------
int ExportFunc01(int a)
{
  return a;
}
//---------------------------------------------------------------------------------------
int ExportFunc02(int a, int b)
{
  return (a+b);
}
//---------------------------------------------------------------------------------------
