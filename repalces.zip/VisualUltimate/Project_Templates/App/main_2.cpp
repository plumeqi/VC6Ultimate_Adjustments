#include <windows.h>
#include <tchar.h>
//-------------------------------------------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE, LPTSTR lpCmdLine, int nCmdShow)
{

  return 0;
}
//-------------------------------------------------------------------------------------------------------------



