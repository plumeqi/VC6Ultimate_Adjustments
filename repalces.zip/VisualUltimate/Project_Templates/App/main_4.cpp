// Windows Header Files:
#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

// Local Header Files
#include "resource.h"

//-------------------------------------------------------------------------------------------------------------
#if _MSC_VER<1300 /*VC6*/
BOOL CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
#else
INT_PTR CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
#endif
{
  switch (message)
  {
    case WM_INITDIALOG:
    {
      HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MEDIUM));
      SendMessage(hDlg, WM_SETICON, FALSE, (LPARAM)hIcon);
      return TRUE;
    }
    case WM_COMMAND:
    {
      switch (LOWORD(wParam))
      {
        case IDOK:
        case IDCANCEL:
          MessageBeep(MB_OK);
          break;
       }
      break;
    }
    case WM_CLOSE:
    {
      DestroyWindow(hDlg);
      break;
    }
    case WM_DESTROY:
    {
      PostQuitMessage(0);
      break;
    }
  }

  return FALSE ;
}

//-------------------------------------------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE, LPTSTR lpCmdLine, int nCmdShow)
{
  //----- How to add class name to dialog resource -----//
  //-- Insert Dialog into resource
  //-- Make sure to Disable "Enable MFC Feature"
  //--   | Right click on "Resource View" - "resource.rc"
  //--   | Select "Property on popup menu
  //--   | Uncheck "Enable MFC Feature"
  //-- Right click on Dialog template of resource editor view
  //-- Select "Properties" to open Dialog properties
  //-- Input your class name in "class name" field

  WNDCLASSEX wcex={0};

  wcex.cbSize = sizeof(WNDCLASSEX);//It is important, otherwise RegisterClassEx will fail.

  GetClassInfoEx(hInstance, _T("#32770"), &wcex);
  wcex.lpszClassName = _T("$$SAFE_ROOT$$");

  ATOM atom=RegisterClassEx(&wcex);

  //--- If you don't want to change dialog class name, remove all of above.
  HWND hWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_$$SAFE_ROOT$$), NULL, DlgProc);
  //You can call GetClassInfoEx to view wndproc address of wcex again.
  //GetClassInfoEx(hInstance, _T("#32770"), &wcex);

  if (!hWnd)
    return FALSE;

  ShowWindow(hWnd, nCmdShow);
  UpdateWindow(hWnd);

  // Main message loop:
  MSG msg;
  while (GetMessage(&msg, NULL, 0, 0))
  {
//	  if( !IsWindow(hWnd) || !IsDialogMessage(hWnd, &msg) )
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }

  return 0; //msg.wParam;
}
//-------------------------------------------------------------------------------------------------------------
